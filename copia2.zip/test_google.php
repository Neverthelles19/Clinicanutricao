<?php
echo "<h1>Teste Google OAuth - copiaCN</h1>";
echo "<p><a href='oauth/google/logingoogle.php'>Testar Login Google</a></p>";
echo "<p>Se funcionar, você será redirecionado para o Google.</p>";
?>