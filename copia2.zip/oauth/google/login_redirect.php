<?php
// Este arquivo serve apenas como redirecionamento para o logingoogle.php
// Mantido para compatibilidade com links existentes
header('Location: logingoogle.php');
exit;