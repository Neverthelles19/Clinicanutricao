<?php
session_start();

include 'conexao.php';

if (!$conexao) {
    die("Erro de conexão com o banco de dados: " . mysqli_connect_error());
}

// Initialize message variables
$mensagem = '';
$tipo_mensagem = '';

// Check for existing session messages and unset them after retrieval
if (isset($_SESSION['mensagem'])) {
    $mensagem = $_SESSION['mensagem'];
    $tipo_mensagem = $_SESSION['tipo_mensagem'] ?? 'info'; // Default to 'info' if not set
    unset($_SESSION['mensagem']);
    unset($_SESSION['tipo_mensagem']);
}

function mapDaysToNumbers($dayNamesString) {
    $dayMap = [
        'Domingo' => '0',
        'Segunda' => '1',
        'Terça'   => '2',
        'Quarta'  => '3',
        'Quinta'  => '4',
        'Sexta'   => '5',
        'Sábado'  => '6'
    ];
    $dayNames = explode(',', $dayNamesString);
    $dayNumbers = [];
    foreach ($dayNames as $dayName) {
        $trimmedDayName = trim($dayName);
        if (isset($dayMap[$trimmedDayName])) {
            $dayNumbers[] = $dayMap[$trimmedDayName];
        }
    }
    return implode(',', $dayNumbers);
}

function buscarClientePorEmail($conexao, $email) {
    $stmt = $conexao->prepare("SELECT id, nome, email, telefone, senha FROM clientes WHERE email = ? LIMIT 1");
    if (!$stmt) {
        throw new Exception("Erro ao preparar consulta do cliente: {$conexao->error}");
    }
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_assoc();
}

function cadastrarCliente($conexao, $nome, $email, $telefone, $senha) {
    $senha_hash = password_hash($senha, PASSWORD_DEFAULT);
    $stmt = $conexao->prepare("INSERT INTO clientes (nome, email, telefone, senha) VALUES (?, ?, ?, ?)");
    if (!$stmt) {
        throw new Exception("Erro ao preparar cadastro de cliente: {$conexao->error}");
    }
    $stmt->bind_param("ssss", $nome, $email, $telefone, $senha_hash);
    if (!$stmt->execute()) {
        throw new Exception("Erro ao cadastrar cliente: {$stmt->error}");
    }
    // Set session variables for the newly registered user
    $_SESSION['cliente_id'] = $conexao->insert_id;
    $_SESSION['nome_cliente'] = $nome;
    $_SESSION['email_cliente'] = $email;
    $_SESSION['telefone_cliente'] = $telefone;
    return $conexao->insert_id;
}

function horarioOcupado($conexao, $profissional_id, $data, $hora) {
    $stmt = $conexao->prepare("SELECT id FROM agendamentos WHERE profissional_id = ? AND data = ? AND hora = ? LIMIT 1");
    if (!$stmt) {
        throw new Exception("Erro ao preparar consulta de agendamento existente: {$conexao->error}");
    }
    $stmt->bind_param("iss", $profissional_id, $data, $hora);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->num_rows > 0;
}

function profissionalValido($conexao, $profissional_id) {
    $stmt = $conexao->prepare("SELECT id FROM profissionais WHERE id = ? LIMIT 1");
    if (!$stmt) {
        error_log("Erro ao preparar consulta de profissional válido: {$conexao->error}");
        return false;
    }
    $stmt->bind_param("i", $profissional_id);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->num_rows > 0;
}

function inserirAgendamento($conexao, $cliente_id, $profissional_id, $servico_id, $nome_cliente, $email, $telefone, $data, $hora) {
    $stmt = $conexao->prepare(
        "INSERT INTO agendamentos (cliente_id, profissional_id, servico_id, nome_cliente, email_cliente, telefone_cliente, data, hora)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)"
    );
    if (!$stmt) {
        throw new Exception("Erro ao preparar inserção de agendamento: {$conexao->error}");
    }
    $stmt->bind_param("iiisssss", $cliente_id, $profissional_id, $servico_id, $nome_cliente, $email, $telefone, $data, $hora);
    if (!$stmt->execute()) {
        throw new Exception("Erro ao realizar o agendamento: {$stmt->error}");
    }
    return true;
}

$servicos = mysqli_query($conexao, "SELECT * FROM servicos");
if (!$servicos) {
    die("Erro ao buscar serviços: " . mysqli_error($conexao));
}

$profissionais = mysqli_query($conexao, "SELECT * FROM profissionais ORDER BY nome");
if (!$profissionais) {
    die("Erro ao buscar profissionais: " . mysqli_error($conexao));
}

// Handle POST request for appointment booking or login/registration
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        // Determine if it's a registration form submission
        $is_cadastro_form = isset($_POST['is_cadastro_form']) && $_POST['is_cadastro_form'] == '1';

        $servico_id = (int)($_POST['servico_id'] ?? 0);
        $profissional_id = (int)($_POST['profissional_id'] ?? 0);
        $data = trim($_POST['data'] ?? '');
        $hora = trim($_POST['hora'] ?? '');

        // Client-related logic (registration or login)
        $cliente_id = null;
        $nome_cliente = '';
        $telefone_cliente = '';
        $email = '';

        if (isset($_SESSION['cliente_id'])) {
            // User is already logged in
            $cliente_id = $_SESSION['cliente_id'];
            $nome_cliente = $_SESSION['nome_cliente'];
            $email = $_SESSION['email_cliente'];
            $telefone_cliente = $_SESSION['telefone_cliente'];
        } else {
            // User is not logged in, handle registration or login from the modal
            if ($is_cadastro_form) {
                // Registration
                $nome_cliente = trim($_POST['nome_cliente_cadastro'] ?? ''); // Use specific names for clarity
                $telefone_cliente = trim($_POST['telefone_cliente_cadastro'] ?? '');
                $email = trim($_POST['email_cliente_cadastro'] ?? '');
                $senha = $_POST['senha_cadastro'] ?? '';

                if (empty($nome_cliente) || empty($telefone_cliente) || empty($email) || empty($senha)) {
                    throw new Exception('Todos os campos obrigatórios para cadastro devem ser preenchidos.');
                }
                if (strlen($senha) < 6) {
                    throw new Exception('A senha deve ter pelo menos 6 caracteres.');
                }

                $existing_client = buscarClientePorEmail($conexao, $email);
                if ($existing_client) {
                    throw new Exception('Já existe um cadastro com este e-mail. Por favor, faça login.');
                }
                $cliente_id = cadastrarCliente($conexao, $nome_cliente, $email, $telefone_cliente, $senha);
                // After successful registration, the session variables are set in cadastrarCliente
            } else {
                // Login
                $login = trim($_POST['email_cliente_login'] ?? ''); // Pode ser email ou telefone
                $senha = $_POST['senha_login'] ?? '';

                if (empty($login) || empty($senha)) {
                    throw new Exception('Por favor, insira seu e-mail ou telefone e senha para fazer login.');
                }

                // Verificar se o login é um email ou telefone
                $is_email = filter_var($login, FILTER_VALIDATE_EMAIL);
                
                if ($is_email) {
                    // Login com email
                    $cliente = buscarClientePorEmail($conexao, $login);
                } else {
                    // Login com telefone
                    $stmt = $conexao->prepare("SELECT id, nome, email, telefone, senha FROM clientes WHERE telefone = ? LIMIT 1");
                    if (!$stmt) {
                        throw new Exception("Erro ao preparar consulta do cliente: {$conexao->error}");
                    }
                    $stmt->bind_param("s", $login);
                    $stmt->execute();
                    $result = $stmt->get_result();
                    $cliente = $result->fetch_assoc();
                }
                
                if (!$cliente || !password_verify($senha, $cliente['senha'])) {
                    throw new Exception('Login ou senha incorretos.');
                }
                
                // Set session variables upon successful login
                $_SESSION['cliente_id'] = $cliente['id'];
                $_SESSION['nome_cliente'] = $cliente['nome'];
                $_SESSION['email_cliente'] = $cliente['email'];
                $_SESSION['telefone_cliente'] = $cliente['telefone'];

                $cliente_id = $cliente['id'];
                $nome_cliente = $cliente['nome'];
                $telefone_cliente = $cliente['telefone'];
                $email = $cliente['email'];
            }
        }

        // Validate selected professional, date, and time
        if (empty($profissional_id) || !profissionalValido($conexao, $profissional_id)) {
            throw new Exception('Profissional selecionado é inválido!');
        }
        if (empty($data)) {
            throw new Exception('Por favor, selecione uma data válida.');
        }
        if (empty($hora)) {
            throw new Exception('Por favor, selecione um horário válido.');
        }

        // Check if the time slot is already taken
        if (horarioOcupado($conexao, $profissional_id, $data, $hora)) {
            throw new Exception('Este horário já está agendado! Por favor, escolha outro.');
        }

        // Insert the appointment
        inserirAgendamento($conexao, $cliente_id, $profissional_id, $servico_id, $nome_cliente, $email, $telefone_cliente, $data, $hora);

        $_SESSION['mensagem'] = 'Agendamento realizado com sucesso!';
        $_SESSION['tipo_mensagem'] = 'success';
        header('Location: index.php'); // Redirect to avoid resubmission
        exit;

    } catch (Exception $e) {
        $_SESSION['mensagem'] = $e->getMessage();
        $_SESSION['tipo_mensagem'] = 'danger';
        // Redirect back to the same page or referer to display the message
        header('Location: ' . $_SERVER['HTTP_REFERER']); 
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agendamento de Serviços - Clínica Nutrição</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />

    <link href="styleUser.css" rel="stylesheet" />
    <link href="stylecadastroUser.css" rel="stylesheet" />
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="floating-shapes">
        <div class="shape"></div>
        <div class="shape"></div>
        <div class="shape"></div>
    </div>

    <header>
        <nav class="navbar navbar-expand-lg">
            <div class="container">
                <a class="navbar-brand d-flex align-items-center gradient-text" href="#">
                    <i class="fas fa-heartbeat me-2"></i>
                    <span>Clínica Nutrição</span>
                </a>
                <div class="ms-auto d-flex">
                    <a href="index.php" class="btn btn-sm rounded-pill px-3 me-2 btn-inicio">
                        <i class="fas fa-home me-1"></i> Início
                    </a>
                    <a href="logout.php" class="btn btn-sm btn-outline-secondary rounded-pill px-3">
                        <i class="fas fa-sign-out-alt me-1"></i> Sair
                    </a>
                </div>
            </div>
        </nav>
    </header>

    <div class="toast-container position-fixed bottom-0 end-0 p-3">
        <?php if (!empty($mensagem)): ?>
            <div class="toast show align-items-center text-white bg-<?= $tipo_mensagem ?> border-0" role="alert" aria-live="assertive" aria-atomic="true">
                <div class="d-flex">
                    <div class="toast-body">
                        <?= htmlspecialchars($mensagem) ?>
                    </div>
                    <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Fechar"></button>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <main>
        <section class="py-5">
            <div class="container">
                <div class="row align-items-center g-4">
                    <div class="col-md-6">
                        <img src="clinica.jpg" alt="Imagem da Clínica de Nutrição" class="img-fluid rounded shadow">
                    </div>
                    <div class="col-md-6">
                        <div class="d-flex align-items-center justify-content-between mb-3">
                            <h2 class="text-primary mb-0">Nossa Clínica</h2>
                            <a href="#agendamento" class="btn agendarBtn ms-3">Agendar agora</a>
                        </div>
                        <div class="d-flex align-items-center mb-3">
                            <span class="me-2 fs-5 fw-bold text-warning">★ 4.7</span>
                            <small class="text-muted">Baseado em 321 avaliações</small>
                        </div>
                        <p class="lead">Cuidar da sua saúde é a nossa prioridade.</p>
                        <p>
                            Fundada com o compromisso de promover o bem-estar e a qualidade de vida, nossa clínica oferece serviços personalizados de nutrição para todas as idades. Contamos com profissionais qualificados, atendimento humanizado e estrutura moderna.
                        </p>
                        <p>
                            Venha conhecer e descubra como podemos te ajudar a alcançar seus objetivos com saúde e equilíbrio!
                        </p>
                    </div>
                </div>
            </div>
        </section>

        <section class="py-5">
            <div class="container" style="max-width: 1320px;">
                <div class="d-flex gap-4" style="justify-content: flex-start;">

                    <div class="info-quadrado">
                        <h3 class="text-dark mb-4" style="font-weight: 700; font-size: 2.2rem; border-bottom: 3px solid #0f3fa8; padding-bottom: 0.3rem;">
                            Informações da Clínica
                        </h3>

                        <div class="info-block">
                            <div class="info-title">
                                <i class="bi bi-geo-alt-fill"></i> Localização
                            </div>
                            <p class="info-text">
                                Rua Nutrição, 123, Bairro Saúde, Cidade - Estado
                            </p>
                            <a href="https://www.google.com/maps" target="_blank" class="btn-maps">
                                Ver no Google Maps <i class="bi bi-arrow-up-right"></i>
                            </a>
                        </div>

                        <div class="info-block">
                            <div class="info-title">
                                <i class="bi bi-clock-fill"></i> Horários de Funcionamento
                            </div>
                            <ul class="list-unstyled info-text">
                                <li>Segunda a Sexta: 08h00 - 18h00</li>
                                <li>Sábado: 09h00 - 13h00</li>
                                <li>Domingo: Fechado</li>
                            </ul>
                        </div>

                        <div class="info-block">
                            <div class="info-title">
                                <i class="bi bi-credit-card-2-front-fill"></i> Formas de Pagamento
                            </div>
                            <p class="info-text">
                                Aceitamos cartão de crédito, débito, Pix e dinheiro.
                            </p>
                        </div>

                        <div class="info-block">
                            <div class="info-title">
                                <i class="bi bi-share-fill"></i> Redes Sociais
                            </div>
                            <div class="d-flex flex-column mt-2 gap-2">
                                <a href="https://instagram.com/clinicanutricao" target="_blank" class="social-link">
                                    <i class="bi bi-instagram"></i> Instagram
                                </a>
                                <a href="https://facebook.com/clinicanutricao" target="_blank" class="social-link">
                                    <i class="bi bi-facebook"></i> Facebook
                                </a>
                                <a href="https://twitter.com/clinicanutricao" target="_blank" class="social-link">
                                    <i class="bi bi-twitter"></i> Twitter
                                </a>
                            </div>
                        </div>
                    </div>

                    <div class="comodidades-quadrados">
                        <div class="comodidade-card">
                            <div class="comodidade-icon">🅿️</div>
                            <div class="comodidade-titulo">Estacionamento</div>
                            <div class="comodidade-texto">Gratuito no local</div>
                        </div>

                        <div class="comodidade-card">
                            <div class="comodidade-icon">📶</div>
                            <div class="comodidade-titulo">Wi-Fi</div>
                            <div class="comodidade-texto">Internet rápida e gratuita</div>
                        </div>

                        <div class="comodidade-card">
                            <div class="comodidade-icon">🧒</div>
                            <div class="comodidade-titulo">Atendimento Infantil</div>
                            <div class="comodidade-texto">Ambiente acolhedor para crianças</div>
                        </div>

                        <div class="comodidade-card">
                            <div class="comodidade-icon">♿</div>
                            <div class="comodidade-titulo">Acessibilidade</div>
                            <div class="comodidade-texto">Estrutura adaptada para todos</div>
                        </div>

                        <div class="comodidade-card">
                            <div class="comodidade-icon">💻</div>
                            <div class="comodidade-titulo">Atendimento Online</div>
                            <div class="comodidade-texto">Consultas via videochamada</div>
                        </div>

                        <div class="comodidade-card">
                            <div class="comodidade-icon">📋</div>
                            <div class="comodidade-titulo">Consultas Personalizadas</div>
                            <div class="comodidade-texto">Planos alimentares exclusivos</div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section id="agendamento" class="py-5">
            <div class="container py-5">
                <h2 class="mb-4 text-start">Agendamento de Serviços de Nutrição</h2>
                <p class="text-start lead">Selecione o serviço desejado para iniciar seu agendamento.</p>

                <div class="d-flex flex-column gap-4 align-items-start" style="max-width: 700px;">
                    <?php
                    // Reseta o ponteiro do resultado da consulta de serviços
                    mysqli_data_seek($servicos, 0); 
                    if (mysqli_num_rows($servicos) > 0) {
                        while($s = mysqli_fetch_assoc($servicos)): ?>
                            <div class="w-100">
                                <div class="card shadow-sm border-start border-4 border-primary">
                                    <div class="card-body d-flex flex-column flex-md-row justify-content-between text-start gap-3">
                                        <div>
                                            <h5 class="mb-2 text-primary"><?= htmlspecialchars($s['servico']) ?></h5>
                                            <p class="mb-0 text-muted">
                                                <strong>Duração:</strong> <?= intval($s['duracao']) ?> min<br>
                                                <strong>Valor:</strong> R$ <?= number_format($s['valor'], 2, ',', '.') ?>
                                            </p>
                                        </div>
                                        <div class="mt-3 mt-md-0">
                                            <button type="button" class="btn btn-outline-primary agendarBtn"
                                                    data-id="<?= $s['id'] ?>"
                                                    data-servico="<?= htmlspecialchars($s['servico']) ?>">
                                                Agendar Agora
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endwhile;
                    } else {
                        echo "<p class='text-start'>Nenhum serviço disponível no momento.</p>";
                    }
                    ?>
                </div>
            </div>
        </section>
    </main>

    <div class="modal fade" id="modalAgendamento" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-xl modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Agendamento: <span id="nomeServicoModal" class="text-info"></span></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fechar"></button>
                </div>
                <div class="modal-body">
                    <div>
                        <label for="selectProfissional" class="form-label fw-bold">Escolha o Profissional:</label>
                        <select id="selectProfissional" class="form-select mb-3">
                            <option value="">-- Selecione um especialista --</option>
                            <?php
                            // Reseta o ponteiro do resultado da consulta de profissionais
                            mysqli_data_seek($profissionais, 0); 
                            if (mysqli_num_rows($profissionais) > 0) {
                                while($p = mysqli_fetch_assoc($profissionais)):
                                    $dias_numericos = mapDaysToNumbers($p['dias_disponiveis']);
                            ?>
                            <option value="<?= $p['id'] ?>"
                                data-dias='<?= json_encode(explode(",", $dias_numericos)) ?>'
                                data-hora-inicio="<?= htmlspecialchars($p['hora_inicio']) ?>"
                                data-hora-fim="<?= htmlspecialchars($p['hora_fim']) ?>"
                            >
                                <?= htmlspecialchars($p['nome']) ?> - **<?= htmlspecialchars($p['especialidade']) ?>**
                            </option>
                            <?php endwhile;
                            } else {
                                echo "<option value=''>Nenhum profissional disponível no momento.</option>";
                            }
                            ?>
                        </select>
                    </div>

                    <div id="calendarioContainer">
                        <h6 class="text-center mt-4 mb-2">Selecione uma data no calendário abaixo:</h6>
                        <div class="d-flex justify-content-between align-items-center mb-2">
                            <button id="btnPrevMes" class="btn btn-outline-secondary btn-sm">< Mês Anterior</button>
                            <h5 id="tituloMesAno" class="mb-0 text-primary"></h5>
                            <button id="btnNextMes" class="btn btn-outline-secondary btn-sm">Próximo Mês ></button>
                        </div>
                        <div id="calendario"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<div class="modal fade" id="modalConfirmacao" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content border-0 shadow-sm rounded-4">
            <div class="modal-header border-0 pb-0">
                <h5 class="modal-title fw-bold">Confirme seu Agendamento</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fechar"></button>
            </div>

            <div class="modal-body pt-2">
                <div class="alert alert-warning mb-4">
                    <i class="fas fa-exclamation-triangle me-2"></i>
                    <strong>Importante:</strong> Para agendar uma consulta, é necessário fazer login ou criar uma conta.
                </div>
                
                <ul class="list-unstyled mb-4">
                    <li class="mb-3">
                        <span class="text-muted small">Serviço</span><br>
                        <span id="confirmServico" class="fw-semibold text-dark"></span>
                    </li>
                    <li class="mb-3">
                        <span class="text-muted small">Profissional</span><br>
                        <span id="confirmProfissional" class="fw-semibold text-dark"></span>
                    </li>
                    <li>
                        <span class="text-muted small">Data</span><br>
                        <span id="confirmData" class="fw-semibold text-dark"></span>
                    </li>
                </ul>

                <div class="mb-3">
                    <label for="selectHora" class="form-label fw-semibold">Escolha o horário:</label>
                    <select id="selectHora" class="form-select" style="max-width: 200px;" onchange="mostrarFormulario()">
                        <option value="">Selecione um horário</option>
                    </select>
                </div>
                
                <script>
                function mostrarFormulario() {
                    const selectHora = document.getElementById('selectHora');
                    const formAgendamento = document.getElementById('formAgendamento');
                    const formCadastro = document.getElementById('formCadastro');
                    const formLogin = document.getElementById('formLogin');
                    const horaSelecionada = selectHora.value;
                    
                    // Atualizar campo oculto
                    document.getElementById('inputHora').value = horaSelecionada;
                    // Limpar todos os campos do formulário
                    document.getElementById('nome_cliente_cadastro').value = '';
                    document.getElementById('telefone_cliente_cadastro').value = '';
                    document.getElementById('email_cliente_cadastro').value = '';
                    document.getElementById('senha_cadastro').value = '';
                    document.getElementById('email_cliente_login').value = '';
                    document.getElementById('senha_login').value = '';


                    if (horaSelecionada && horaSelecionada !== '') {
                        // Mostrar o formulário
                        formAgendamento.style.display = 'block';
                        
                        <?php if (isset($_SESSION['cliente_id'])): ?>
                        // Se o usuário estiver logado, mostrar mensagem de confirmação
                        const nomeCliente = "<?= htmlspecialchars($_SESSION['nome_cliente'] ?? '') ?>";
                        const emailCliente = "<?= htmlspecialchars($_SESSION['email_cliente'] ?? '') ?>";
                        
                        // Ocultar formulários de login/cadastro
                        if (formCadastro) formCadastro.style.display = 'none';
                        if (formLogin) formLogin.style.display = 'none';
                        
                        // Ocultar botões de alternância
                        document.querySelector('.btn-group').style.display = 'none';
                        
                        // Remover alertas existentes
                        const alertasExistentes = formAgendamento.querySelectorAll('.alert');
                        alertasExistentes.forEach(alerta => alerta.remove());
                        
                        // Adicionar mensagem de usuário logado
                        const infoHtml = `
                            <div class="alert alert-success mb-4">
                                <i class="fas fa-user-check me-2"></i>
                                <strong>Você está logado como:</strong> ${nomeCliente} (${emailCliente})
                            </div>
                            <div class="d-grid mb-4">
                                <button type="submit" class="btn btn-primary btn-lg" onclick="document.getElementById('formAgendamento').submit();">
                                    <i class="fas fa-calendar-check me-2"></i>Confirmar Agendamento
                                </button>
                            </div>
                        `;
                        formAgendamento.insertAdjacentHTML('afterbegin', infoHtml);
                        
                        <?php else: ?>
                        // Se o usuário não estiver logado, mostrar formulário de cadastro por padrão
                        if (formCadastro) formCadastro.style.display = 'block';
                        if (formLogin) formLogin.style.display = 'none';
                        
                        // Atualizar botões
                        document.getElementById('btnCadastro').classList.add('active');
                        document.getElementById('btnLogin').classList.remove('active');
                        
                        // Definir como cadastro
                        document.getElementById('isCadastroForm').value = '1';
                        
                        // Remover alertas existentes
                        const alertasExistentes = formAgendamento.querySelectorAll('.alert-info');
                        alertasExistentes.forEach(alerta => alerta.remove());
                        
                        // Adicionar mensagem informativa
                        const alertHtml = `
                            <div class="alert alert-info mb-4">
                                <i class="fas fa-info-circle me-2"></i>
                                <strong>Atenção:</strong> Para agendar uma consulta, é necessário fazer login ou criar uma conta.
                            </div>
                        `;
                        formAgendamento.insertAdjacentHTML('afterbegin', alertHtml);
                        <?php endif; ?>
                    } else {
                        formAgendamento.style.display = 'none';
                    }
                }
                </script>

                <form method="POST" action="index.php" id="formAgendamento" style="display: none;">
                    <input type="hidden" name="servico_id" id="inputServicoId">
                    <input type="hidden" name="profissional_id" id="inputProfissionalId">
                    <input type="hidden" name="data" id="inputData">
                    <input type="hidden" name="hora" id="inputHora">
                    <input type="hidden" name="is_cadastro_form" id="isCadastroForm" value="0">
                    
                    <div class="d-flex justify-content-center mb-4">
                        <div class="btn-group" role="group">
                            <button type="button" class="btn btn-outline-primary active" id="btnCadastro">Novo Cadastro</button>
                            <button type="button" class="btn btn-outline-primary" id="btnLogin">Já tenho conta</button>
                        </div>
                    </div>

                    <div id="formCadastro" class="signup-container">
                        <div class="signup-card">
                            <div class="signup-header bg-primary text-white p-4 rounded-top">
                                <h2 class="mb-0"><i class="fas fa-user-plus me-2"></i>Cadastro</h2>
                                <p class="text-white-50 mt-2 mb-0">Crie sua conta para agendar:</p>
                            </div>

                            <div class="signup-body p-4">
                                <div class="mb-3">
                                    <label for="nome_cliente_cadastro" class="form-label">Seu Nome Completo</label>
                                    <div class="input-group">
                                        <span class="input-group-text"><i class="fas fa-user"></i></span>
                                        <input type="text" class="form-control" name="nome_cliente_cadastro" id="nome_cliente_cadastro" placeholder="Nome Sobrenome" required>
                                    </div>
                                </div>

                                <div class="mb-3">
                                    <label for="telefone_cliente_cadastro" class="form-label">Telefone (com DDD)</label>
                                    <div class="input-group">
                                        <span class="input-group-text"><i class="fas fa-phone"></i></span>
                                        <input type="tel" class="form-control" name="telefone_cliente_cadastro" id="telefone_cliente_cadastro" placeholder="(XX) XXXXX-XXXX" pattern="\(\d{2}\) \d{4,5}-\d{4}" required>
                                    </div>
                                </div>

                                <div class="mb-3">
                                    <label for="email_cliente_cadastro" class="form-label">E-mail</label>
                                    <div class="input-group">
                                        <span class="input-group-text"><i class="fas fa-envelope"></i></span>
                                        <input type="email" class="form-control" name="email_cliente_cadastro" id="email_cliente_cadastro" placeholder="seu.email@exemplo.com" required>
                                    </div>
                                </div>

                                <div class="mb-4">
                                  <label for="senha_cadastro" class="form-label">Crie sua Senha</label>
                                  <div class="input-group">
                                      <span class="input-group-text"><i class="fas fa-lock"></i></span>
                                      <input type="password" id="senha_cadastro" class="form-control" name="senha_cadastro" required minlength="6">
                                      <span class="input-group-text" style="cursor:pointer;" onclick="togglePasswordVisibility(this, 'senha_cadastro')">
                                          <i class="fas fa-eye"></i>
                                      </span>
                                  </div>
                              </div>
                                <div class="text-center mt-4">
                                    <p class="mt-4">Já tem cadastro? <a href="#" id="linkFazerLogin" class="text-primary">Faça Login</a></p>
                                    <button type="submit" class="btn btn-primary btn-signup btn-lg px-5 py-2" id="btnCadastrarAgendar" onclick="document.getElementById('formAgendamento').submit();">
                                        <i class="fas fa-user-plus me-2"></i>Cadastrar e Agendar
                                    </button>
                                    
                                    <div class="position-relative my-4">
                                        <hr>
                                        <span class="position-absolute top-0 start-50 translate-middle bg-white px-3 text-muted">ou</span>
                                    </div>
                                    
                                    <div class="d-grid">
                                        <a href="oauth/google/logingoogle.php" class="btn btn-outline-danger d-flex align-items-center justify-content-center">
                                            <i class="fab fa-google me-2"></i> Cadastrar com Google
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div id="formLogin" class="login-container" style="display: none;">
                        <div class="login-card">
                            <div class="login-header bg-primary text-white p-4 rounded-top">
                                <h2 class="mb-0"><i class="fas fa-sign-in-alt me-2"></i>Login</h2>
                                <p class="text-white-50 mt-2 mb-0">Bem-vindo(a) ao sistema</p>
                            </div>

                            <div class="login-body p-4">
                                <div class="mb-3">
                                    <label for="email_cliente_login" class="form-label">E-mail ou Telefone</label>
                                    <div class="input-group">
                                        <span class="input-group-text"><i class="fas fa-user"></i></span>
                                        <input type="text" name="email_cliente_login" class="form-control" id="email_cliente_login" required>
                                    </div>
                                </div>

                                <div class="mb-4">
                                  <label for="senha_login" class="form-label">Senha</label>
                                  <div class="input-group">
                                      <span class="input-group-text"><i class="fas fa-lock"></i></span>
                                      <input type="password" id="senha_login" class="form-control" name="senha_login" required minlength="6">
                                      <span class="input-group-text" style="cursor:pointer;" onclick="togglePasswordVisibility(this, 'senha_login')">
                                          <i class="fas fa-eye"></i>
                                      </span>
                                  </div>
                                  <div class="text-end mt-2">
                                      <a href="recuperar_senha.php" class="small text-muted">Esqueceu sua senha?</a>
                                  </div>
                              </div>

                                <div class="mt-3 text-center">
                                    <button type="submit" class="btn btn-primary btn-signup btn-lg px-5 py-2" onclick="document.getElementById('formAgendamento').submit();">
                                        <i class="fas fa-sign-in-alt me-2"></i>Login e Agendar
                                    </button>

                                    <div class="position-relative my-4">
                                        <hr>
                                        <span class="position-absolute top-0 start-50 translate-middle bg-white px-3 text-muted">ou</span>
                                    </div>

                                    <div class="d-grid gap-2">
                                        <a href="#" class="btn btn-outline-primary d-flex align-items-center justify-content-center">
                                            <i class="fab fa-google me-2"></i> Entrar com Google
                                        </a>
                                        <a href="#" class="btn btn-outline-primary d-flex align-items-center justify-content-center">
                                            <i class="fab fa-facebook-f me-2"></i> Entrar com Facebook
                                        </a>
                                    </div>

                                    <p class="mt-4">Não tem cadastro? <a href="#" id="linkFazerCadastro" class="text-primary">Cadastre-se</a></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
    <footer class="bg-light py-4 mt-5">
        <div class="container text-center">
            <p class="mb-0 text-muted">&copy; <?= date('Y'); ?> Clínica Nutrição. Todos os direitos reservados.</p>
        </div>
    </footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script src="script.js"></script>
    
    <script>
        // Inicializa e mostra os Toasts do Bootstrap
        document.addEventListener('DOMContentLoaded', function() {
            var toastElList = [].slice.call(document.querySelectorAll('.toast'));
            var toastList = toastElList.map(function(toastEl) {
                return new bootstrap.Toast(toastEl, { autohide: true, delay: 5000 }); // Oculta automaticamente após 5 segundos
            });
            toastList.forEach(toast => toast.show());
        });

        /**
         * Função chamada pelo script.js para verificar o status de login do cliente.
         * Se o cliente estiver logado, preenche os campos do formulário e esconde as opções de login/cadastro.
         */

            function checkAndSetLoginStatus() {
            // Limpar todos os campos do formulário
            if (document.getElementById('nome_cliente_cadastro')) document.getElementById('nome_cliente_cadastro').value = '';
            if (document.getElementById('telefone_cliente_cadastro')) document.getElementById('telefone_cliente_cadastro').value = '';
            if (document.getElementById('email_cliente_cadastro')) document.getElementById('email_cliente_cadastro').value = '';
            if (document.getElementById('senha_cadastro')) document.getElementById('senha_cadastro').value = '';
            if (document.getElementById('email_cliente_login')) document.getElementById('email_cliente_login').value = '';
            if (document.getElementById('senha_login')) document.getElementById('senha_login').value = '';
            
            <?php if (isset($_SESSION['cliente_id'])): ?>
                // Cliente está logado: Preenche os dados e desabilita/oculta os formulários de login/cadastro
                const nomeCliente = "<?= htmlspecialchars($_SESSION['nome_cliente']) ?>";
                const emailCliente = "<?= htmlspecialchars($_SESSION['email_cliente']) ?>";
                const telefoneCliente = "<?= htmlspecialchars($_SESSION['telefone_cliente']) ?>";

                // Oculta completamente as seções de login/cadastro no modal de confirmação
                document.getElementById('formCadastro').style.display = 'none';
                document.getElementById('formLogin').style.display = 'none';
                
                // Oculta os botões de alternância
                document.querySelector('.btn-group').style.display = 'none';
                
                // Adiciona uma mensagem informando que o usuário está logado
                const infoHtml = `
                    <div class="alert alert-success mb-4">
                        <i class="fas fa-user-check me-2"></i>
                        <strong>Você está logado como:</strong> ${nomeCliente} (${emailCliente})
                    </div>
                    <div class="d-grid mb-4">
                        <button type="submit" class="btn btn-primary btn-lg">
                            <i class="fas fa-calendar-check me-2"></i>Confirmar Agendamento
                        </button>
                    </div>
                `;
                
                // Insere a mensagem antes do formulário
                const formContainer = document.getElementById('formAgendamento');
                formContainer.insertAdjacentHTML('afterbegin', infoHtml);

                // Remove o atributo 'required' dos campos de login/cadastro para evitar validação desnecessária
                document.getElementById('nome_cliente_cadastro').removeAttribute('required');
                document.getElementById('telefone_cliente_cadastro').removeAttribute('required');
                document.getElementById('email_cliente_cadastro').removeAttribute('required');
                document.getElementById('senha_cadastro').removeAttribute('required');
                document.getElementById('email_cliente_login').removeAttribute('required');
                document.getElementById('senha_login').removeAttribute('required');

                // Garante que o input oculto não ative o fluxo de cadastro/login no backend se o usuário já estiver logado
                document.getElementById('isCadastroForm').value = '0'; // Indica que não é uma operação de cadastro/login
            <?php else: ?>
                // Cliente NÃO está logado: Mostra o formulário de cadastro por padrão
                mostrarFormCadastro(); // Função definida no script.js
                document.getElementById('isCadastroForm').value = '1'; // Define como cadastro inicialmente
                
                // Adiciona uma mensagem informando que é necessário login ou cadastro
                const alertHtml = `
                    <div class="alert alert-info mb-4">
                        <i class="fas fa-info-circle me-2"></i>
                        <strong>Atenção:</strong> Para agendar uma consulta, é necessário fazer login ou criar uma conta.
                    </div>
                `;
                document.getElementById('formAgendamento').insertAdjacentHTML('afterbegin', alertHtml);
            <?php endif; ?>
        }

        // Event listeners para alternar entre os formulários de Cadastro e Login
        document.getElementById('linkFazerLogin').addEventListener('click', function(e) {
            e.preventDefault();
            document.getElementById('formCadastro').style.display = 'none';
            document.getElementById('formLogin').style.display = 'block';
            document.getElementById('btnCadastro').classList.remove('active');
            document.getElementById('btnLogin').classList.add('active');
            document.getElementById('isCadastroForm').value = '0'; // Define para login
        });

        document.getElementById('linkFazerCadastro').addEventListener('click', function(e) {
            e.preventDefault();
            document.getElementById('formCadastro').style.display = 'block';
            document.getElementById('formLogin').style.display = 'none';
            document.getElementById('btnCadastro').classList.add('active');
            document.getElementById('btnLogin').classList.remove('active');
            document.getElementById('isCadastroForm').value = '1'; // Define para cadastro
        });
        
        // Event listeners para os botões de alternância entre cadastro e login
        document.getElementById('btnCadastro').addEventListener('click', function() {
            document.getElementById('formCadastro').style.display = 'block';
            document.getElementById('formLogin').style.display = 'none';
            document.getElementById('btnCadastro').classList.add('active');
            document.getElementById('btnLogin').classList.remove('active');
            document.getElementById('isCadastroForm').value = '1';
        });
        
        document.getElementById('btnLogin').addEventListener('click', function() {
            document.getElementById('formCadastro').style.display = 'none';
            document.getElementById('formLogin').style.display = 'block';
            document.getElementById('btnCadastro').classList.remove('active');
            document.getElementById('btnLogin').classList.add('active');
            document.getElementById('isCadastroForm').value = '0';
        });

        // Função para alternar a visibilidade da senha
        function togglePasswordVisibility(button, inputId) {
            const input = document.getElementById(inputId) || button.parentElement.querySelector('input');
            const icon = button.querySelector('i');
            
            if (input.type === 'password') {
                input.type = 'text';
                icon.classList.remove('fa-eye');
                icon.classList.add('fa-eye-slash');
            } else {
                input.type = 'password';
                icon.classList.remove('fa-eye-slash');
                icon.classList.add('fa-eye');
            }
        }
        
        // Event listeners para o botão de mostrar/esconder senha
        document.querySelectorAll('.toggle-password').forEach(button => {
            button.addEventListener('click', function() {
                const input = this.parentElement.querySelector('input');
                togglePasswordVisibility(this);
            });
        });
    </script>
</body>
</html>